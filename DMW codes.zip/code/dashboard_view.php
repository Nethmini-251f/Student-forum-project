<html>
<head>
    <title>Dashboard</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="style.css">
</head>

<body>

<nav class="navbar navbar-dark bg-dark px-4">

    <span class="navbar-brand">
        Forum Dashboard
    </span>

    <div>

        <span class="text-white me-3">
            Welcome <?php echo $username; ?>
        </span>

        <a href="logout.php"
        class="btn btn-danger btn-sm">
            Logout
        </a>

    </div>

</nav>
<!-- COLOR BANNER -->

<div class="container mt-4">

<div class="p-5 rounded-4 shadow text-center hero-banner">

<h1 class="display-5 fw-bold text-white">

    Welcome to Student Forum

</h1>

<p class="lead text-white">

    Share ideas, ask questions, and help others.

</p>

</div>

</div>



<div class="container mt-4">

<div class="card p-4 shadow">

<h3>Create Thread</h3>

<form action="post.php"
method="POST">

<input type="text"
name="title"
placeholder="Thread Title"
class="form-control mb-3">

<textarea name="content"
placeholder="Thread Content"
class="form-control mb-3"></textarea>

<button class="btn btn-success">
Post Thread
</button>

</form>

</div>

<br>

<h3>All Threads</h3>

<?php foreach($threads as $row){ ?>

<div class="card p-3 mb-3 shadow">

<h5>
<?php echo $row['title']; ?>
</h5>

<p>
<?php echo $row['content']; ?>
</p>

</div>

<?php } ?>

</div>

</body>
</html>
