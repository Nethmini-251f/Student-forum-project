<?php
$conn = new mysqli("localhost", "root", "", "nibmforum");

if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
}
?>

