<?php
session_start();
include "dbconnect.php";

$user_id = $_SESSION['user_id'];
$title = $_POST['title'];
$content = $_POST['content'];

$sql = "INSERT INTO threads (user_id, title, content)
        VALUES ('$user_id', '$title', '$content')";

$conn->query($sql);

header("Location: dashboard.php");
?>