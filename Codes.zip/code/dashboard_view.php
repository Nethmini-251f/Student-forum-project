<!-- dashboard.php -->

<?php

include "dbconnect.php";

$query = "SELECT * FROM threads ORDER BY id DESC";
$result = mysqli_query($conn, $query);
?>


<html>
<head>

    <title>DiscussHub</title>

    <!-- Bootstrap -->

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="style.css">

</head>

<body>

<!-- NAVBAR -->

<nav class="navbar navbar-expand-lg navbar-dark p-3">

<div class="container">

<a class="navbar-brand" href="#">DiscussHub</a>

<div class="ms-auto d-flex gap-3">

<a href="#postform"class="btn btn-post"
onclick="alert('Create your new discussion thread here!')">+ New Post</a>

<div class="username">

<?php
echo $_SESSION['username'];
?>

</div>

<a href="logout.php" class="btn btn-danger">
Logout
</a>

</div>

</div>

</nav>

<!-- MAIN CONTAINER -->

<div class="container mt-4"
style="max-width:1000px;">

<!-- HERO SECTION -->

<div class="hero-banner">

<h1>Welcome to DiscussHub</h1>

<p>Discuss ideas,share knowledge and solve problems together.</p>

</div>

<!-- DISCUSSIONS -->

<h2 class="mt-5 fw-bold">Discussions</h2>

<?php

while($row = mysqli_fetch_assoc($result))
{
?>

<div class="post-card">

<div class="post-title">

<?php
echo $row['title'];
?>

</div>

<div class="mt-2 text-secondary">

Posted by user

</div>

<div class="post-content">

<?php
echo $row['content'];
?>

</div>

<hr>

<div class="d-flex justify-content-between">

<a href="#"class="btn btn-primary"onclick="alert('Comment feature coming soon!')">Comment</a>
<a href="#"class="btn btn-danger"onclick="alert('Thread reported successfully!')">Report</a>

</div>

</div>

<?php
}
?>

</div>

<div id="postform"
class="card p-4 shadow border-0 rounded-4">

<h3 class="mb-4 text-center">
Create New Thread
</h3>

<form action="post.php" method="POST">

<div class="mb-3">

<label class="form-label">
Thread Title
</label>

<input type="text"
name="title"
placeholder="Enter thread title"

<div class="mb-3">

<class="form-control">

</div>
<label class="form-label">
Thread Content
</label>

<textarea name="content"
rows="5"
placeholder="Write your content here..."
class="form-control"></textarea>

</div>

<button class="btn btn-warning w-100">Post Thread</button>

</form>

</div>
</body>
</html>