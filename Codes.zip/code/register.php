<?php
include "dbconnect.php";

$username = $_POST['username'];
$email = $_POST['email'];

$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

$InsertData = "INSERT INTO users (username, email, password)
VALUES ('$username', '$email', '$password')";

if(mysqli_query($conn,$InsertData))
{
    echo "Registered successfully!";
}
else
{
    echo "Error: " . $conn->error;
}
?>