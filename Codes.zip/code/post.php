<?php

include "dbconnect.php";

$title = mysqli_real_escape_string(
$conn,
$_POST['title']
);

$content = mysqli_real_escape_string(
$conn,
$_POST['content']
);

$InsertData = "INSERT INTO threads(title, content)

VALUES('$title', '$content')";

if($conn->query($InsertData) === TRUE)
{
    header("Location: dashboard.php");
}
else
{
    echo "Error: " . $conn->error;
}

?>