<?php
session_start();
include "dbconnect.php";

if (!isset($_SESSION['username'])) {
    header("Location: index.html");
}

$username = $_SESSION['username'];
?>

<?php

include "dbconnect.php";

if(!isset($_SESSION['username']))
{
    header("Location:index.html");
}

$username = $_SESSION['username'];

$result = mysqli_query($conn,
"SELECT * FROM threads");

$threads = [];

while($row = mysqli_fetch_assoc($result))
{
    $threads[] = $row;
}

include "dashboard_view.php";

?>